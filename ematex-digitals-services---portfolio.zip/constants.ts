
export const SKILLS = [
  {
    category: "Software Engineering",
    skills: [
      "React & Next.js",
      "TypeScript",
      "Node.js & Express",
      "Python (Django, Flask)",
      "Database Management (SQL, NoSQL)",
      "Cloud Services (AWS, Vercel)",
      "CI/CD & DevOps",
      "REST & GraphQL APIs",
    ],
  },
  {
    category: "Digital Marketing",
    skills: [
      "Search Engine Optimization (SEO)",
      "Search Engine Marketing (SEM)",
      "Content Strategy & Marketing",
      "Social Media Management",
      "Pay-Per-Click (PPC) Campaigns",
      "Email Marketing Automation",
      "Google Analytics & Data Analysis",
      "Conversion Rate Optimization",
    ],
  },
  {
    category: "IT Project Management",
    skills: [
      "Agile & Scrum Methodologies",
      "Kanban & Lean Practices",
      "Project Planning & Roadmapping",
      "Risk Management & Mitigation",
      "Stakeholder Communication",
      "Budgeting & Resource Allocation",
      "Jira & Confluence",
      "Team Leadership & Mentoring",
    ],
  },
];

export const PROJECTS = [
  {
    title: "Enterprise CRM Platform",
    description:
      "A full-stack web application for managing customer relationships, sales pipelines, and marketing campaigns, built with scalability and security in mind.",
    image: "https://picsum.photos/seed/crm/600/400",
    tags: ["React", "Node.js", "SQL", "Agile"],
    skill: "Software Engineering"
  },
  {
    title: "Global SEO Strategy for E-commerce",
    description:
      "Led a comprehensive SEO overhaul for an international e-commerce brand, resulting in a 150% increase in organic traffic and a 60% uplift in online sales.",
    image: "https://picsum.photos/seed/seo/600/400",
    tags: ["SEO", "Content Strategy", "Google Analytics"],
    skill: "Digital Marketing"
  },
  {
    title: "Cloud Migration Initiative",
    description:
      "Managed the end-to-end migration of on-premise infrastructure to AWS for a mid-sized tech company, reducing operational costs by 40% and improving system uptime.",
    image: "https://picsum.photos/seed/cloud/600/400",
    tags: ["IT Project Management", "AWS", "Risk Management"],
    skill: "IT Project Management"
  },
  {
    title: "Mobile Banking App Development",
    description:
      "Developed a cross-platform mobile banking application focusing on user experience and security, featuring biometric login and real-time transaction notifications.",
    image: "https://picsum.photos/seed/mobile/600/400",
    tags: ["React Native", "TypeScript", "Scrum"],
    skill: "Software Engineering"
  },
   {
    title: "Social Media Influencer Campaign",
    description:
      "Orchestrated a successful influencer marketing campaign across multiple platforms, reaching over 5 million users and boosting brand engagement by 200%.",
    image: "https://picsum.photos/seed/social/600/400",
    tags: ["Social Media", "PPC", "Content Strategy"],
    skill: "Digital Marketing"
  },
   {
    title: "SaaS Product Launch",
    description:
      "Oversaw the complete project lifecycle for a new SaaS product, from ideation and development to market launch, acquiring 10,000 users in the first quarter.",
    image: "https://picsum.photos/seed/saas/600/400",
    tags: ["Jira", "Stakeholder Communication", "Roadmapping"],
    skill: "IT Project Management"
  },
];
