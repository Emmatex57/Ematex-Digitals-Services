
import React from 'react';
import { WhatsAppIcon, MailIcon, LinkedInIcon } from './icons';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-slate-800">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl font-bold text-white mb-4">
          Get In Touch
        </h2>
        <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto">
          I'm currently available for freelance work and open to discussing new projects. Whether you have a question or just want to say hi, feel free to reach out.
        </p>
        <div className="flex justify-center items-center space-x-8">
          <a 
            href="https://wa.me/2347057676478"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="WhatsApp"
            className="text-gray-400 hover:text-cyan-400 transition-transform duration-300 transform hover:scale-125"
          >
            <WhatsAppIcon className="w-12 h-12" />
          </a>
          <a 
            href="mailto:emmanuelajayi608@gmail.com"
            aria-label="Email"
            className="text-gray-400 hover:text-cyan-400 transition-transform duration-300 transform hover:scale-125"
          >
            <MailIcon className="w-12 h-12" />
          </a>
          <a 
            href="https://www.linkedin.com" // Placeholder, replace with actual LinkedIn profile URL
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="text-gray-400 hover:text-cyan-400 transition-transform duration-300 transform hover:scale-125"
          >
            <LinkedInIcon className="w-12 h-12" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Contact;
