
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-slate-900">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center text-white mb-12">
          About Me
        </h2>
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/3 flex justify-center">
            <img 
              src="https://picsum.photos/seed/portrait/400/400" 
              alt="Emmanuel Ajayi"
              className="rounded-full w-64 h-64 md:w-80 md:h-80 object-cover border-4 border-cyan-500 shadow-xl shadow-cyan-500/20"
            />
          </div>
          <div className="md:w-2/3 text-lg text-gray-400 space-y-4">
            <p>
              I'm Emmanuel Ajayi, the founder of <span className="text-cyan-400 font-semibold">Ematex Digitals Services</span>. With a deep passion for technology and business strategy, I've cultivated a unique multidisciplinary skill set that bridges the gap between technical execution and market success.
            </p>
            <p>
              My journey began in software engineering, where I honed my skills in building robust, scalable, and user-centric applications. This technical foundation gave me the insight to not only create products but also to understand how they fit into the larger business ecosystem.
            </p>
            <p>
              Driven by a desire to see great products succeed, I expanded my expertise into digital marketing and IT project management. Today, I offer a holistic service that takes ideas from conception to launch and beyond, ensuring technical excellence, market visibility, and seamless project delivery. My mission is to empower businesses to thrive in the digital landscape.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
