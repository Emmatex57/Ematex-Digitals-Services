
import React, { useState, useEffect, useRef } from 'react';

const TYPING_SPEED = 100;
const DELETING_SPEED = 50;
const DELAY = 2000;

const roles = [
  "Software Engineer.",
  "Digital Marketer.",
  "IT Project Manager.",
];

const Hero: React.FC = () => {
  const [text, setText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [loopNum, setLoopNum] = useState(0);
  const typingTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    const handleType = () => {
      const i = loopNum % roles.length;
      const fullText = roles[i];

      setText(
        isDeleting
          ? fullText.substring(0, text.length - 1)
          : fullText.substring(0, text.length + 1)
      );

      let typeSpeed = TYPING_SPEED;
      if (isDeleting) {
        typeSpeed /= 2;
      }

      if (!isDeleting && text === fullText) {
        typeSpeed = DELAY;
        setIsDeleting(true);
      } else if (isDeleting && text === '') {
        setIsDeleting(false);
        setLoopNum(loopNum + 1);
        typeSpeed = 500;
      }

      typingTimeoutRef.current = window.setTimeout(handleType, typeSpeed);
    };
    
    typingTimeoutRef.current = window.setTimeout(handleType, 250);

    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, [text, isDeleting, loopNum]);

  return (
    <section id="hero" className="min-h-screen flex items-center bg-cover bg-center" style={{ backgroundImage: "linear-gradient(rgba(15, 23, 42, 0.8), rgba(15, 23, 42, 0.9)), url('https://picsum.photos/seed/hero/1920/1080')" }}>
      <div className="container mx-auto px-6 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-4 leading-tight">
          Emmanuel Ajayi
        </h1>
        <p className="text-2xl md:text-4xl text-gray-300 mb-8 font-light">
          I am a <span className="text-cyan-400 font-semibold border-r-4 border-cyan-400 animate-pulse">{text}</span>
        </p>
        <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-400 mb-12">
          Welcome to Ematex Digitals Services. We build innovative software, drive market growth, and manage complex projects to deliver outstanding results.
        </p>
        <a href="#contact" className="bg-cyan-500 text-white font-bold py-3 px-8 rounded-full hover:bg-cyan-600 transition-all duration-300 text-lg shadow-lg shadow-cyan-500/30 transform hover:scale-105">
          Let's Connect
        </a>
      </div>
    </section>
  );
};

export default Hero;
